import { Router } from 'express';
import { Server } from 'socket.io';
import * as storage from './storage';
import { authenticate } from './auth';

const createRoutes = (io: Server) => {
  const router = Router();

  router.get('/recipients', authenticate, async (req, res) => {
    const data = await storage.getRecipients();
    res.json(data);
  });

  router.get('/medications', authenticate, async (req, res) => {
    const data = await storage.getMedications();
    res.json(data);
  });

  io.on('connection', (socket) => {
    console.log('Client connected via WebSocket');
    socket.on('update', (payload) => {
      io.emit('refresh', payload);
    });
  });

  return router;
};

export default createRoutes;