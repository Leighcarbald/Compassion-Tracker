export const getRecipients = async () => {
  return [
    { id: 1, name: 'Alice Smith' },
    { id: 2, name: 'Bob Johnson' },
  ];
};

export const getMedications = async () => {
  return [
    { id: 1, name: 'Aspirin' },
    { id: 2, name: 'Metformin' },
  ];
};