import axios from 'axios';

export const fetchMedicationInfo = async (name: string) => {
  try {
    const response = await axios.get(`https://api.example.com/meds?name=${name}`);
    return response.data;
  } catch (error) {
    console.error('Error fetching medication info:', error);
    return null;
  }
};